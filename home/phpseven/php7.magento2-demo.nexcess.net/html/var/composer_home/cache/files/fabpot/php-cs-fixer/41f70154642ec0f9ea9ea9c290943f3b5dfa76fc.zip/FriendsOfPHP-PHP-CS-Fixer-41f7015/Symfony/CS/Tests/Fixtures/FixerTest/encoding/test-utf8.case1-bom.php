﻿<?php

echo 'ą';
