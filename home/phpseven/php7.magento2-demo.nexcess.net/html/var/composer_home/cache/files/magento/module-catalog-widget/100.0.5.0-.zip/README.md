# CatalogWidget

**CatalogWidget** contains various widgets that extend Catalog module functionality:
- Product List widget provides widget that contains product list created using rule based filter.
