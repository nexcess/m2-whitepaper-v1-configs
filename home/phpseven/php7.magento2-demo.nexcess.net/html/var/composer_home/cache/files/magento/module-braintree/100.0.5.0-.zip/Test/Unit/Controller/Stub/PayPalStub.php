<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\Braintree\Test\Unit\Controller\Stub;

class PayPalStub extends \Magento\Braintree\Controller\PayPal
{
    public function execute()
    {
        // Empty method stub for test
    }
}
