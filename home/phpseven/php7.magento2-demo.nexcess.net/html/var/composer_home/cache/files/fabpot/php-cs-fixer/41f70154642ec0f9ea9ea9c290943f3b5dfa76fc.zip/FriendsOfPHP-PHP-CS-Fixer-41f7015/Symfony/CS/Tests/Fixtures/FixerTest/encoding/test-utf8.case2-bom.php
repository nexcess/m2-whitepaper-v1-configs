﻿abc
<?php

echo 'ą';
