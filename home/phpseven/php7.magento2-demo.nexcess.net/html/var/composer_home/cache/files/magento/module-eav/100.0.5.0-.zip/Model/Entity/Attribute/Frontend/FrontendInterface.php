<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

/**
 * Entity attribute frontend interface
 *
 * Frontend is providing the user interface for the attribute
 *
 */
namespace Magento\Eav\Model\Entity\Attribute\Frontend;

interface FrontendInterface
{
}
