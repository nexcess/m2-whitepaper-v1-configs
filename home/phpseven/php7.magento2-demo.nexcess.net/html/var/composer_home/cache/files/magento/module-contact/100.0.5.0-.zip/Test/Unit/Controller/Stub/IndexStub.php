<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\Contact\Test\Unit\Controller\Stub;

class IndexStub extends \Magento\Contact\Controller\Index
{
    public function execute()
    {
        // Empty method stub for test
    }
}
