<?php

namespace Test\AAaa;

class test
{
    var $testA;
    public $test_B;
        public $testC;
}
