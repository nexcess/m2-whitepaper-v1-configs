Magento_CatalogSearch module is an extension of Magento_Catalog module that allows to use search engine for product searching capabilities.
The module implements Magento_Search library interfaces.
