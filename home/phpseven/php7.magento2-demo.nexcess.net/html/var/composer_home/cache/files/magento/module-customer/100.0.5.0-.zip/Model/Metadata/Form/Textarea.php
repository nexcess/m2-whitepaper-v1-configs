<?php
/**
 * Form Element Textarea Data Model
 *
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Customer\Model\Metadata\Form;

class Textarea extends Text
{
}
