<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Ui\Api\Data;

/**
 * Bookmark extension interface.
 * @api
 */
interface BookmarkExtensionInterface extends \Magento\Framework\Api\ExtensionAttributesInterface
{

}
