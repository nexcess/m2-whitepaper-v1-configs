abc
<?php

echo 'ą';
