Magento_WishlistSampleData module consists of installation scripts and fixtures.
