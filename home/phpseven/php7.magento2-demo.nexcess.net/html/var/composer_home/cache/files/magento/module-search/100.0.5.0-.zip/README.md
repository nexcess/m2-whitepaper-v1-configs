Magento_Search module introduces basic search functionality and provides interfaces that allow to implement search for specific module.
