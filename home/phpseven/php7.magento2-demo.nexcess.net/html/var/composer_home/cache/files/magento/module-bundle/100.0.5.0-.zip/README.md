Magento_Bundle module introduces new product type in the Magento application named Bundle Product.
This module is designed to extend existing functionality of Magento_Catalog module by adding new product type.
