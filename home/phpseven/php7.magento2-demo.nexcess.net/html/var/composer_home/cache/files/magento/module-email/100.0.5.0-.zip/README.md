# Email

**Email** enables you to manage email templates, which are used when you send email through the
*\Magento\Framework\Mail\TransportInterface* implementations.
