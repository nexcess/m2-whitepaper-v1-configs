<?php
/**
 *
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Sales\Controller\Order;

use Magento\Sales\Controller\OrderInterface;

class PrintInvoice extends \Magento\Sales\Controller\AbstractController\PrintInvoice implements OrderInterface
{
}
