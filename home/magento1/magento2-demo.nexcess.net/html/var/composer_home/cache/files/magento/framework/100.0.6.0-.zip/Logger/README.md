# Logger

**Logger** provides a standard mechanism to log to system and error logs.
