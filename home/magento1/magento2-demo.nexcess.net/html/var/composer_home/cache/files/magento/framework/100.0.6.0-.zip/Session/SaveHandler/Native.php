<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Framework\Session\SaveHandler;

/**
 * Php native session save handler
 */
class Native extends \SessionHandler
{
}
