The Magento_Ups module implements integration with the United Parcel Service shipping carrier.
