Magento_Indexer module is a base of Magento Indexing functionality.
It allows to read indexers configuration, represent indexers in admin, control their mode, regenerate indexers by schedule.
There are 2 modes of the Indexers: "Update on save" and "Update by schedule".
Manual re-index can be performed via console by running index.php script.
