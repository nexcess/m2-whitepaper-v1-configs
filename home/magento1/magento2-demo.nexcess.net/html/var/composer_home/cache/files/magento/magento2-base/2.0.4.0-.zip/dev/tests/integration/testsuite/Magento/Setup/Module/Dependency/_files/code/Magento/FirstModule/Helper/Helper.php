<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\FirstModule\Helper;

class Helper
{
    /**
     * @return void
     */
    public function test()
    {
        new Magento\LibFirst();
    }
}
