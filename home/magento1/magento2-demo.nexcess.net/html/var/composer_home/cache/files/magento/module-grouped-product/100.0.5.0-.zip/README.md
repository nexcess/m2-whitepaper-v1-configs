Magento_GroupedProduct module provides ability to offer several standalone products for sale as a group on the same Product Detail page.
It can offer variations of a product, or group them by season or theme to create a coordinated set.
Products can be purchased separately or as a set.
Each product purchased appears in the Shopping Cart as a separate item.
This module extends the existing functionality of Magento_Catalog module by adding new product type.
