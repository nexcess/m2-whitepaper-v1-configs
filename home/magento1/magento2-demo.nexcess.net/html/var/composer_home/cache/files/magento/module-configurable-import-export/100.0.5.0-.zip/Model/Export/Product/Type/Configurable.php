<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\ConfigurableImportExport\Model\Export\Product\Type;

class Configurable extends \Magento\CatalogImportExport\Model\Export\Product\Type\AbstractType
{
}
