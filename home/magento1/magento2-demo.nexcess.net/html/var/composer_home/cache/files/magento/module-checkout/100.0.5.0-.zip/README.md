Magento\Checkout module allows merchant to register sale transaction with the customer. Module implements consumer flow
that includes such actions like adding products to cart, providing shipping and billing information and confirming
the purchase.