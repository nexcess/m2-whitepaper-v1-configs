Magento_Catalog module functionality is represented by the following sub-systems:
 - Products Management. It includes CRUD operation of product, product media, product attributes, etc...
 - Category Management. It includes CRUD operation of category, category attributes

Catalog module provides mechanism for creating new product type in the system.
Catalog module provides API filtering that allows to limit product selection with advanced filters.
