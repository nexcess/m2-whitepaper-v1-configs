<?php
/**
 *
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Downloadable\Controller\Adminhtml\Downloadable\Product\Edit;

class AlertsPriceGrid extends \Magento\Catalog\Controller\Adminhtml\Product\AlertsPriceGrid
{
}
