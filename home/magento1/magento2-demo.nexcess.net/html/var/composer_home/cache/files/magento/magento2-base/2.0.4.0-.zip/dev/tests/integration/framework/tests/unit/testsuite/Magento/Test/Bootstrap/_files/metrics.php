<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

return ['Fixture Label' => ['fixture_key_one', 'fixture_key_two']];
