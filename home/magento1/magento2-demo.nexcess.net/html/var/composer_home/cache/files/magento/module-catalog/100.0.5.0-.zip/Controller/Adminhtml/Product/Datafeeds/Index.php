<?php
/**
 *
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Catalog\Controller\Adminhtml\Product\Datafeeds;

class Index extends \Magento\Backend\App\Action
{
    /**
     * @return void
     */
    public function execute()
    {
    }
}
