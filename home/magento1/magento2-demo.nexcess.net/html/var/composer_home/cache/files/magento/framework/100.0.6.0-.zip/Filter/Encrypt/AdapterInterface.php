<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Framework\Filter\Encrypt;

/**
 * Encrypt adapter interface
 */
interface AdapterInterface extends \Zend_Filter_Encrypt_Interface
{
}
