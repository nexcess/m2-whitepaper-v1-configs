<?php
/**
 *
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Sales\Controller\Adminhtml\Order\Invoice;

class Email extends \Magento\Sales\Controller\Adminhtml\Invoice\AbstractInvoice\Email
{
}
