<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Framework\Message;

/**
 * Message session model
 */
class Session extends \Magento\Framework\Session\SessionManager
{
}
