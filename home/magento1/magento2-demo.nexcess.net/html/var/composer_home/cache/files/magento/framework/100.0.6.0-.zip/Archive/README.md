Archive library provides functionalities for archiving files including following formats:
* tar
* gz
* bzip2