/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
/*global define*/
define(
    [
        'Magento_Customer/js/model/address-list',
        'Magento_Checkout/js/model/address-converter'
    ],
    function(addressList, addressConverter) {
        "use strict";
        return function(addressData) {
            var address = addressConverter.formAddressDataToQuoteAddress(addressData);
            var isAddressUpdated = addressList().some(function(currentAddress, index, addresses) {
                if (currentAddress.getKey() == address.getKey()) {
                    addresses[index] = address;
                    return true;
                }
                return false;
            });
            if (!isAddressUpdated) {
                addressList.push(address);
            } else {
                addressList.valueHasMutated();
            }
            return address;
        };
    }
);