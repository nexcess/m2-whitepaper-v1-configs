# Message

**Message** library is responsible for message creation and management.